The scripts and data files contained in this directory may be used to reproduce the results in Hooten et al. (2018) related to the movement of sandhill cranes. 

The script fit_sacr_dep.R uses the functions in the included 'smover' R package (by Henry Scharf) to fit the process convolution model based on an unobserved social network to the telemetry data in sacr_social_analysis.RData. The script fit_sacr_indep.R fits a simplified model with a fixed, empty social network to the same data. The scripts figures_dep.R and figures_indep.R may be used to make some of the figures in Hooten et al. (2018), as well as provide some basic model fitting diagnostics. Finally, the script plot_path_uncertainty.R may be used to compare the uncertainty about the true tajectories of the sandhill cranes under the two models (Figure 7 in Hooten et al. 2018).

The 'smover' R package may be installed using the following command in an interactive R session:

install.packages("smover_1.5.tar.gz", repos=NULL)