###############################################################################
###############################################################################
## Henry Scharf
##
## This script uses the smover.social.fit() function to fit the process convolution model to SACR telemetry data.
###############################################################################
###############################################################################
## libraries + seed ----
library(smover); library(sp); library(rworldmap)
seed <- 1985
## load 5 individuals during fall 2013 ----
load(file = "sacr_social_analysis.RData")
ids <- sort(unique(sacr.dat$PTT_ID))
coordinates(sacr.dat) = ~Easting + Northing
proj4string(sacr.dat) <- CRS(paste("+proj=aeqd +lat_1=47 +lat_2=55",
                                   "+lat_0=51 +lon_0=-110 +x_0=0 +y_0=0",
                                   "+ellps=GRS80 +datum=NAD83",
                                   "+units=km +no_defs"))
## making lists of observations ----
n.indiv <- length(ids)
s.sacr <- sapply(ids, function(id){
  coordinates(sacr.dat)[sacr.dat$PTT_ID == id, ]
})
## standardize time interval to [0, 1] ----
ot.sacr <- sapply(ids, function(id){
  (sacr.dat$POSIX[sacr.dat$PTT_ID == id])
})
time.window <- range(sacr.dat$POSIX)
time.window.numeric <- as.numeric(time.window)
ot.sacr.real <- ot.sacr
ot.sacr <- sapply(ids, function(id){
  (as.numeric(sacr.dat$POSIX[sacr.dat$PTT_ID == id]) - time.window.numeric[1]) /
    diff(time.window.numeric)
})
## load + project map ----
map <- getMap()[c(28,103,167),] #[c(28,103,135,167),] #With Russia
map.proj <- spTransform(map, sacr.dat@proj4string)
## plot to check projection ----
plot.colors <- RColorBrewer::brewer.pal(9, "Set1")
## layout
layout(matrix(c(2, 3, 1, 1), 2, 2), height = c(0.95, 1))
par(mar = c(4.1, 0.6, 0.6, 0.6))
plot(map.proj, bg = "dodgerblue4", lwd = 1, col = "gray", xlim = c(150, 1000), ylim = c(-2400, 1600))
for(i in 1:n.indiv){
  points(s.sacr[[i]],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
## northing
par(mar = c(1.6, 4.1, 0.6, 0.1))
plot(ot.sacr[[1]], s.sacr[[1]][, 1],
     type = "n", xlab = "", xaxt = "n", ylab = "northing",
     ylim = range(lapply(s.sacr, function(s.i){range(s.i[, 1])})))
for(i in 1:n.indiv){
  points(ot.sacr[[i]], s.sacr[[i]][, 1],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
## easting
par(mar = c(4.1, 4.1, 0.1, 0.1))
plot(ot.sacr[[1]], s.sacr[[1]][, 2],
     type = "n", xlab = "time", xaxt = "n", ylab = "easting",
     ylim = range(lapply(s.sacr, function(s.i){range(s.i[, 2])})))
axis(1, seq(min(ot.sacr[[1]]), max(ot.sacr[[1]]), l=5), as.Date(seq(min(ot.sacr.real[[1]]), max(ot.sacr.real[[1]]), l=5)))
for(i in 1:n.indiv){
  points(ot.sacr[[i]], s.sacr[[i]][, 2],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
########## ----
## FIT ### ----
########## ----
## knots and dimension ----
## set kpd "movement" knots per day
kpd <- 5
knots.fit <- seq(min(unlist(ot.sacr)), max(unlist(ot.sacr)), l=diff(time.window.numeric)/3600/24*kpd)
## skpd social knots per day
skpd <- 2/7
n.w.knots <- ceiling(diff(time.window.numeric)/3600/24*skpd)
knots.w.fit <- seq(min(unlist(ot.sacr)), max(unlist(ot.sacr)), l=n.w.knots)
## dimension of latent social space
d.w <- 2
## kernels ----
kernel.s <- kernel.samp()$kernel.gauss
row.normalize.s <- TRUE
l.s <- 1
kernel.w <- kernel.samp()$kernel.gauss
row.normalize.w <- TRUE
l.w <- 1
row.normalize.soc = TRUE
l.soc <- 1
## euclidean distance + link for latent social space ----
method.lp <- "dist"; link.lp <- function(w){exp(-w^2)}
## priors ----
priors <- list("phi.s" = c(2, 200),
               "phi.w" = c(2, 5),
               "sigsq.s" = c(1e-3, 1e-3),
               "sigsq.muos" = c(1e-3, 1e-3),
               "sigsq.mu" = c(1e-3, 1e-3),
               "sigsq.0" = c(1, 10),
               "sigsq.w" = c(52, 10))
## seed ----
set.seed(seed)
## starting values ----
starting.values <- list("phi.s" = 1e-3,
                        "phi.w" = 3/(length(knots.w.fit)),
                        "sigsq.muos" = 1e5,
                        "sigsq.s" = 1e0,
                        "sigsq.w" = 1,
                        "sigsq.0" = 5e0,
                        "epsilon.w" = array(rnorm(n.indiv*d.w*length(knots.w.fit)),
                                            dim = c(n.indiv, length(knots.w.fit), d.w)))
## tuning parameter starting values ----
tuning <- list("phi.s" = 5e-5, "phi.w" = 1/100,
               "sigsq.muos" = starting.values$sigsq.muos*1e-1,
               "sigsq.mu" = starting.values$sigsq.mu*1e-2, 
               "sigsq.0" = starting.values$sigsq.0,
               "epsilon.w" = 1e-1)
## fixed parameters ----
fixed <- list("phi.s" = F, "phi.w" = TRUE,
              "sigsq.0" = F, "sigsq.muos" = F,
              "sigsq.mu" = TRUE,
              "sigsq.s" = F, "sigsq.w" = F,
              "epsilon.w" = rep(F, n.indiv), "w.tilde" = F)
## N.iterations & fitting parameters ----
N.iterations <- 5e0 ## set to 5e0 in case of accidental execution
batch.size <- min(50, N.iterations); adapt.kill <- floor(N.iterations / 2);
verbose <- TRUE
# ## no longer using the rSVD feature, or the SMW for that matter
# epsilon.w.ess <- FALSE
# approx <- NA; approx.err.prop <- 5e-2
# approx.batch.size <- 0; approx.adapt.kill <- N.iterations
# n.cores <- NULL; max.attempts.ess <- 32
## build smover_mcmc object ----
smover_mcmc_sacr.object <- list("starting.values" = starting.values,
                           "priors" = priors, "tuning" = tuning, "fixed" = fixed)
smover_mcmc_sacr.object$data <- list("s" = s.sacr,
                                "observation.times" = ot.sacr)
smover_mcmc_sacr.object$smoother <- list("knots.fit" = knots.fit,
                                       "kernel.s" = kernel.s, 
                                       "row.normalize.s" = row.normalize.s, "l.s" = l.s)
smover_mcmc_sacr.object$network <- list("kernel.w" = kernel.w, "d.w" = d.w,
                                      "network.obj" = list("w.tilde" = NULL, "knots" = knots.fit),
                                      "knots.w.fit" = knots.w.fit,
                                      "row.normalize.w" = row.normalize.w, "l.w" = l.w,
                                      "row.normalize.soc" = row.normalize.soc, "l.soc" = l.soc,
                                      "method.lp" = method.lp,
                                      "link.lp" = link.lp)
smover_mcmc_sacr.object$fixed <- fixed
class(smover_mcmc_sacr.object) <- "smover_mcmc"
## [SLOW] actual fitting ----
save.rate <- 1e2; progress.file <- "progress_sacr_est_sigsq_w.RData"
system.time({
  fit.social.sacr.mcmc <- fit.mcmc(smover_mcmc.object = smover_mcmc_sacr.object,
                                   N.iterations = N.iterations,
                                   batch.size = batch.size,
                                   verbose = verbose, 
                                   save.rate = save.rate, 
                                   progress.file = progress.file)
})
## burnin + used.iterations ----
used.iterations <- (floor(N.iterations * 0.5)):(N.iterations + 1)
burnin <- (1:(N.iterations + 1))[-used.iterations]
## [SLOWish] composition sampling of mu ----
interp.times <- lapply(ot.sacr, function(ot.sacr.i){
  seq(min(unlist(ot.sacr.i)),
      max(unlist(ot.sacr.i)), l=4e2)})
system.time({
  mu <- comp.sample.mu(smover_social_mcmc.object = fit.social.sacr.mcmc,
                       interp.times = interp.times,
                       used.iterations = used.iterations)
  fit.social.sacr.mcmc$chains$mu <- mu$mu
})
## SAVE OUTPUT ----
output <- list("fit.social.sacr.mcmc" = fit.social.sacr.mcmc,
               "date" = fit.social.sacr.mcmc$date)
sacr.crs <- sacr.dat@proj4string
save(output, sacr.crs, interp.times, ot.sacr.real, time.window.numeric, 
     file = paste("fit_sacr_", fit.social.sacr.mcmc$date, ".RData", sep = ""))
## PLOT DIAGNOSTICS ----
source("figures_dep.R")
