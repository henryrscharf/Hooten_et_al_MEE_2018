################################################################################ ----
################################################################################ ----
## Henry Scharf
##
## This script plots the path uncertainty for fits to the full and independent models.
################################################################################ ----
################################################################################ ----
## libraries ----
library(sp)
## load path uncertainty calculations ----
# load("path_uncertainty_indepYYYMMDD_HHMMSS.RData")
mu.quantiles.indep <- mu.quantiles
# load("path_uncertaintyYYYMMDD_HHMMSS.RData")
## load fits ----
load("fit_sacr_20180301_200124.RData")
list2env(output, envir = environment())
n.indiv <- length(fit.social.sacr.mcmc$smover_mcmc.object$data$s)
if(!exists("it.sacr.real")){
  it.sacr.real <- sapply(1:n.indiv, function(i){
    as.POSIXct(interp.times[[i]]*diff(time.window.numeric) + time.window.numeric[1],
               origin = "1970-01-01")
  }, simplify = F)
}
if(exists("mu")){
  rm(mu); gc(0)
}
## PLOT PATH UNCERTAINTY ----
## filename ----
png(file = paste("path_uncertainty", fit.social.sacr.mcmc$date_time, ".png", sep = ""),
    width = 10, height = 7, units = "in", res = 72*3)
## plot commands ----
it.sacr.real <- sapply(1:n.indiv, function(i){
  as.POSIXct(interp.times[[i]]*diff(time.window.numeric) + time.window.numeric[1],
             origin = "1970-01-01")
}, simplify = F)
axis_ticks <- as.POSIXct(paste("2013-", c("09-01", "09-16", "10-01", "10-12", "10-22"), sep = ""), 
                         origin = "1970-01-01", tz = "UTC")
axis_labels <- c("Sep 01", "Sep 16", "Oct 01", "Oct 12", "Oct 22")
plot.colors <- RColorBrewer::brewer.pal(9, "Set1")
n.indiv <- dim(mu.quantiles)[2]
layout(1:n.indiv)
ylims <- range(c(0, mu.quantiles, mu.quantiles.indep))
for(i in 1:n.indiv){
  xaxt <- "n"
  if(i == 1){
    par(mar = c(0.1, 3.6, 3.1, 0.1))
  }
  if(i > 1 & i < n.indiv){
    par(mar = c(1.6, 3.6, 1.6, 0.1))
  }
  if(i == n.indiv){
    par(mar = c(3.1, 3.6, 0.1, 0.1))
  }
  plot(it.sacr.real[[i]], mu.quantiles[, i], ylab = "", xlab = "",
       type = 'l', bty = "n", lwd = 2, col = plot.colors[i], ylim = ylims, 
       xaxt = "n", yaxt = "n", cex.axis = 1.4)
  rug(ot.sacr.real[[i]], lwd = 1)
  if(i == n.indiv) axis(1, at = axis_ticks, labels = axis_labels, line = 0.5, cex.axis = 1.4)
  lines(it.sacr.real[[i]], mu.quantiles.indep[, i], col = plot.colors[i], lwd = 2, lty = 2)
  if(i == 3){
    mtext("kms", 2, line = 2.5)
    axis(2, cex.axis = 1.4)
  }
  if(i == 1){
    legend("topleft", lwd = 2, lty = 1:2, legend = c("full", "indep"), bty = "n", 
           cex = 1.5, inset = c(-0.04, -0.4), xpd = T)
  }
}
## dev.off ----
dev.off()
