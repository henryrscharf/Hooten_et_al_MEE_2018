###############################################################################
###############################################################################
## Henry Scharf
##
## This script makes diagnostic plots for the output of a call to 
## smover.social.fit() for sandhill crane telemetry data.
###############################################################################
###############################################################################
## libraries ----
library(smover); library(rworldmap)
# ## optionally load another complete fit ----
# date <- "YYYYMMDD_HHMMSS"
# load(paste("fit_sacr_", date, ".RData", sep = ""))
# list2env(output, envir = environment())
## compute needed variables ----
N.iterations <- length(fit.social.sacr.mcmc$chains$phi.s) - 1
used.iterations <- (floor(N.iterations * 0.5) + 2):(N.iterations + 1)
burnin <- (1:(N.iterations + 1))[-used.iterations]
n.indiv <- dim(fit.social.sacr.mcmc$chains$epsilon.w[[1]])[1]
map <- getMap()[c(28,103,135,167),]
map.proj <- spTransform(map, sacr.crs)
# PLOT DIAGNOSTICS ----
## filename ----
pdf(file = paste("diagnostics_sacr_", fit.social.sacr.mcmc$date, ".pdf", sep = ""))
## plots ----
plot(fit.social.sacr.mcmc, which.plots = c(1), ask = F, burnin = burnin)
plot(fit.social.sacr.mcmc, which.plots = c(2), ask = F, burnin = burnin)
plot(smover_social_mcmc.object = fit.social.sacr.mcmc, which.plots = c(3),
     net.summary = c("sample", "median"),
     ask = F, burnin = burnin, n.networks = 300,
     col.net = alpha(viridis::viridis(min(length(used.iterations), 300)),
                     min(1, 10/(min(length(used.iterations), 300)))))
plot(smover_social_mcmc.object = fit.social.sacr.mcmc, which.plots = c(3),
     net.summary = c("median", "quantiles"),
     ask = F, burnin = burnin, n.networks = 1)
plot(fit.social.sacr.mcmc, which.plots = c(4), ask = F, burnin = burnin,
     interp.times = interp.times, mu.i = 1:n.indiv, mu.map = F, zoom = c(6, 6, 6))
## dev.off ----
dev.off()
## filename ----
png(file = paste("paths_sacr_", fit.social.sacr.mcmc$date, ".png", sep = ""), 
    width = 12, height = 7, units = "in", res = 72*3)
## plot north/east ----
## load + project map
it.sacr.real <- sapply(1:n.indiv, function(i){
  as.POSIXct(interp.times[[i]]*diff(time.window.numeric) + time.window.numeric[1],
             origin = "1970-01-01")
}, simplify = F)
map <- getMap(resolution = "high")[c(236, 148, 39, 191), ] #With Russia
map.proj <- spTransform(map, sacr.crs)
indivs <- 1:n.indiv
plot.colors <- RColorBrewer::brewer.pal(9, "Set1")
path.subset <- used.iterations
if(length(path.subset) > 100){
  path.subset <- sort(sample(used.iterations, size = 100))
}
alpha.lev <- max(1e-3, min(1, 15/length(path.subset)))
axis_ticks <- as.POSIXct(paste("2013-", c("09-01", "09-16", "10-01", "10-12", "10-22"), sep = ""), 
                         origin = "1970-01-01", tz = "UTC")
way.pts <- sapply(axis_ticks, function(tick){
  min(which(format(it.sacr.real[[1]], "%Y-%m-%d") == tick))
})
axis_labels <- c("Sep 01", "Sep 16", "Oct 01", "Oct 12", "Oct 22")
## layout
layout(matrix(c(1, 1, 2, 3), 2, 2), heights = c(0.95, 1), widths = c(1, 6/7))
par(mar = c(0.6, 0.6, 0.6, 0.6))
plot(map.proj, bg = "dodgerblue4", lwd = 1, col = "gray", 
     xlim = c(-800, 800), ylim = c(-2400, 3600))
for(iter in path.subset){
  for(i in indivs){
    lines(fit.social.sacr.mcmc$chains$mu[[iter]][[i]],
          col = scales::alpha(plot.colors[i], alpha.lev))
    # way.pts <- seq(1, length(interp.times[[i]]), l=6)
    points(fit.social.sacr.mcmc$chains$mu[[iter]][[i]][way.pts, ],
           col = scales::alpha(plot.colors[i], alpha.lev),
           pch = 1:length(way.pts), cex = 2)
  }
}
for(i in indivs){
  points(fit.social.sacr.mcmc$smover_mcmc.object$data$s[[i]],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
## northing 
par(mar = c(1.6, 2.1, 0.6, 0.1))
plot(it.sacr.real[[indivs[1]]],
     fit.social.sacr.mcmc$chains$mu[[N.iterations]][[indivs[1]]][, 1],
     type = "n", xlab = "", xaxt = "n", ylab = "", yaxt = "n", bty = "o",
     ylim = 1.1*range(unlist(lapply(fit.social.sacr.mcmc$chains$mu[path.subset],
                                function(mu.iter){
                                  lapply(mu.iter, function(mu.iter.i){
                                    range(mu.iter.i[, 1])
                                  })
                                }))))
mtext(text = "Northing", side = 2, line = 0.5, cex = 1.2)
for(iter in path.subset){
  for(i in indivs){
    lines(it.sacr.real[[i]],
          fit.social.sacr.mcmc$chains$mu[[iter]][[i]][, 1],
          col = scales::alpha(plot.colors[i], alpha.lev))
    # way.pts <- seq(1, length(interp.times[[i]]), l=6)
    # points(interp.times[[i]][way.pts],
    #        fit.social.sacr.mcmc$chains$mu[[iter]][[i]][way.pts, 1],
    #        col = scales::alpha(plot.colors[i], alpha.lev),
    #        pch = 1:length(way.pts), cex = 2)
  }
}
for(i in indivs){
  points(fit.social.sacr.mcmc$smover_mcmc.object$data$observation.times[[i]],
         fit.social.sacr.mcmc$smover_mcmc.object$data$s[[i]][, 1],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
points(it.sacr.real[[i]][way.pts],
       rep(par()$usr[3] - 0.04 * diff(par()$usr[4:3]), length(way.pts)),
       col = "gray", lwd = 2,
       pch = 1:length(way.pts), cex = 2, xpd = T)
# legend("topleft", lwd = 2, col = plot.colors, legend = 1:n.indiv, bty = "n")
## easting
par(mar = c(2.6, 2.1, 0.1, 0.1))
plot(it.sacr.real[[indivs[1]]],
     fit.social.sacr.mcmc$chains$mu[[N.iterations]][[indivs[1]]][, 2],
     type = "n", xlab = "", ylab = "", yaxt = "n", xaxt = "n",
     ylim = 1.1*range(unlist(lapply(fit.social.sacr.mcmc$chains$mu[path.subset],
                                function(mu.iter){
                                  lapply(mu.iter, function(mu.iter.i){
                                    range(mu.iter.i[, 2])
                                  })
                                }))))
axis(1, at = axis_ticks, labels = axis_labels, cex.axis = 1.2)
mtext(text = "Easting", side = 2, line = 0.5, cex = 1.2)
for(iter in path.subset){
  for(i in indivs){
    lines(it.sacr.real[[i]],
          fit.social.sacr.mcmc$chains$mu[[iter]][[i]][, 2],
          col = scales::alpha(plot.colors[i], alpha.lev))
  }
}
for(i in indivs){
  points(fit.social.sacr.mcmc$smover_mcmc.object$data$observation.times[[i]],
         fit.social.sacr.mcmc$smover_mcmc.object$data$s[[i]][, 2],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
points(it.sacr.real[[i]][way.pts],
       rep(par()$usr[3] - 0.04 * diff(par()$usr[4:3]), length(way.pts)),
       col = "gray", lwd = 2,
       pch = 1:length(way.pts), cex = 2, xpd = T)
## dev.off ----
dev.off()
## Effective Sample Size and Gelman diagnostic ----
library(coda); library(smover)
used.iterations.1 <- used.iterations[1:floor(length(used.iterations)/2)]
used.iterations.2 <- used.iterations[seq(floor(length(used.iterations)/2) + 1,
                                         length.out = length(used.iterations.1))]
gelman.stat <- lapply(fit.social.sacr.mcmc$chains[1:6], function(param){
  gelman.diag(list(as.mcmc(param[used.iterations.1]),
                   as.mcmc(param[used.iterations.2])), autoburnin = F)
})
gelman.stat
ess <- lapply(fit.social.sacr.mcmc$chains[1:6], function(param){
  effectiveSize(as.mcmc(param[used.iterations]))
})
ess
## Network ESS + Gelman diagnostic ----
if(!exists("w.tildes")){
  system.time({
  w.tildes <- sapply(used.iterations, function(iter){
    w.tilde <- build.W(epsilon.w = fit.social.sacr.mcmc$chains$epsilon.w[[iter]],
                       kernel.w = fit.social.sacr.mcmc$smover_mcmc.object$network$kernel.w,
                       phi.w = fit.social.sacr.mcmc$chains$phi.w[iter],
                       knots.w = fit.social.sacr.mcmc$smover_mcmc.object$network$knots.w.fit,
                       # knots = fit.social.sacr.mcmc$smover_mcmc.object$smoother$knots.fit,
                       knots = interp.times[[1]],
                       row.normalize.w = fit.social.sacr.mcmc$smover_mcmc.object$network$row.normalize.w,
                       l.w = fit.social.sacr.mcmc$smover_mcmc.object$network$l.w,
                       method.lp = fit.social.sacr.mcmc$smover_mcmc.object$network$method.lp,
                       link.lp = fit.social.sacr.mcmc$smover_mcmc.object$network$link.lp)$w.tilde
  }, simplify = FALSE)
})
}
## one example ----
i <- 1; j <- 2; time <- floor(length(fit.social.sacr.mcmc$smover_mcmc.object$smoother$knots.fit)/2)
w <- unlist(lapply(w.tildes, function(w.tilde){w.tilde[i, j, time]}))
gelman.stat.w <- gelman.diag(list(as.mcmc(w[used.iterations.1 - min(used.iterations.1) + 1]),
                                  as.mcmc(w[used.iterations.1 - min(used.iterations.1) + 1 + length(used.iterations.1)])),
                             autoburnin = F)
gelman.stat.w
ess.w <- effectiveSize(w)
ess.w; ess.w/length(used.iterations)
# ## all times and interactions [SLOW] ----
# # esss <- array(NA, dim = c(n.indiv, n.indiv, length(fit.social.sacr.mcmc$smover_mcmc.object$smoother$knots.fit)))
# esss <- array(NA, dim = dim(w.tildes[[1]]))
# system.time({
#   for(i in 1:(n.indiv - 1)){
#     for(j in (i + 1):n.indiv){
#       for(time in 1:length(interp.times[[1]])){
#         w <- unlist(lapply(w.tildes, function(w.tilde){w.tilde[i, j, time]}))
#         ess.w <- effectiveSize(w)
#         esss[i, j, time] <- ess.w
#       }
#     }
#   }
# })
# mean(esss, na.rm = T); sd(esss, na.rm = T)
# ## filename ----
# pdf(file = paste("network_ess_", fit.social.sacr.mcmc$date, ".pdf", sep = ""))
# ## plot commands ----
# layout(matrix(c(1:4, 
#                 0, 5:7, 
#                 0, 0, 8:9, 
#                 rep(0, 3), 10), 4, 4))
# par(mar = c(1, 1, 1, 1))
# for(i in 1:(n.indiv - 1)){
#   for(j in (i + 1):n.indiv){
#     plot(esss[i, j, ], xlab = "", ylab = "", ylim = range(esss, na.rm = T))
#   }
# }
# ## dev.off ----
# dev.off()
## ----
## compute path uncertainty ----
get.path.dist <- function(mu = NULL, mu.mean = NULL){
  mu.array <- array(unlist(mu), dim = c(dim(mu[[1]]), length(mu)))
  mu.radii <- sapply(1:dim(mu.array)[3], function(i){
    sapply(1:dim(mu.array)[1], function(t){
      dist(rbind(mu.array[t, , i], mu.mean[t, , i]))
    })
  })
  return(mu.radii)
}
system.time({
  mu.array <- array(unlist(fit.social.sacr.mcmc$chains$mu[used.iterations]),
                    dim = c(dim(fit.social.sacr.mcmc$chains$mu[[1]][[1]]), 
                            length(fit.social.sacr.mcmc$chains$mu[[1]]), 
                            length(used.iterations)))
  mu.mean <- apply(mu.array, 1:3, mean)
  cl <- parallel::makeForkCluster(3)
  mu.radii <- array(parallel::parSapply(cl, used.iterations, FUN = function(iter){
    get.path.dist(mu = fit.social.sacr.mcmc$chains$mu[[iter]], mu.mean = mu.mean)
    }), dim = c(dim(mu.mean)[c(1, 3)], length(used.iterations)))
  parallel::stopCluster(cl)
  mu.quantiles <- apply(mu.radii, 1:2, function(mu.i.t){
    quantile(mu.i.t, prob = 0.95)
  })
})
## SAVE PATH UNCERTAINTY QUANTILES ----
save(mu.quantiles, used.iterations, N.iterations, 
     file = paste("path_uncertainty", fit.social.sacr.mcmc$date, ".RData", sep = ""))
## ----
## NETWORK STATISTICS ----
## make network  ----
if(!exists("w.tildes")){
  system.time({
    w.tildes <- sapply(used.iterations, function(iter){
      w.tilde <- build.W(epsilon.w = fit.social.sacr.mcmc$chains$epsilon.w[[iter]],
                         kernel.w = fit.social.sacr.mcmc$smover_mcmc.object$network$kernel.w,
                         phi.w = fit.social.sacr.mcmc$chains$phi.w[iter],
                         knots.w = fit.social.sacr.mcmc$smover_mcmc.object$network$knots.w.fit,
                         # knots = fit.social.sacr.mcmc$smover_mcmc.object$smoother$knots.fit,
                         knots = interp.times[[1]],
                         row.normalize.w = fit.social.sacr.mcmc$smover_mcmc.object$network$row.normalize.w,
                         l.w = fit.social.sacr.mcmc$smover_mcmc.object$network$l.w,
                         method.lp = fit.social.sacr.mcmc$smover_mcmc.object$network$method.lp,
                         link.lp = fit.social.sacr.mcmc$smover_mcmc.object$network$link.lp)$w.tilde
    }, simplify = FALSE)
  })
}
network <- array(rowMeans(matrix(unlist(w.tildes), ncol = length(used.iterations))),
                 dim = c(n.indiv, n.indiv, length(interp.times[[1]])))
## GLOBAL ----
## network density / total edge weight ----
system.time({
  density <- matrix(unlist(lapply(w.tildes, function(w.tilde){
    (apply(w.tilde, 3, sum) - n.indiv)/2
  })), ncol = length(used.iterations))
  density.quantiles <- apply(density, 1, function(density){
    quantile(density, probs = c(0.025, 0.25, 0.5, 0.75, 0.975))
  })
})
## mean degree ----
system.time({
  mean_degrees <- matrix(unlist(lapply(w.tildes, function(w.tilde){
    apply(apply(w.tilde, 2:3, sum) - 1, 2, mean)
  })), ncol = length(used.iterations))
  mean_degree.quantiles <- apply(mean_degrees, 1, function(mean_degree){
    quantile(mean_degree, probs = c(0.025, 0.25, 0.5, 0.75, 0.975))
  })
})
## max degree ----
system.time({
  max_degrees <- matrix(unlist(lapply(w.tildes, function(w.tilde){
    apply(apply(w.tilde, 2:3, sum) - 1, 2, max)
  })), ncol = length(used.iterations))
  max_degree.quantiles <- apply(max_degrees, 1, function(max_degree){
    quantile(max_degree, probs = c(0.025, 0.25, 0.5, 0.75, 0.975))
  })
})
## min degree ----
system.time({
  min_degrees <- matrix(unlist(lapply(w.tildes, function(w.tilde){
    apply(apply(w.tilde, 2:3, sum) - 1, 2, min)
  })), ncol = length(used.iterations))
  min_degree.quantiles <- apply(min_degrees, 1, function(min_degree){
    quantile(min_degree, probs = c(0.025, 0.25, 0.5, 0.75, 0.975))
  })
})
## LOCAL ----
## individual degrees ----
system.time({
  ind_degrees <- array(unlist(lapply(w.tildes, function(w.tilde){
    apply(w.tilde, 2:3, sum) - 1
  })), dim = c(n.indiv, length(interp.times[[1]]), length(used.iterations)))
  ind_degree.quantiles <- apply(ind_degrees, 1:2, function(ind_degree){
    quantile(ind_degree, probs = c(0.025, 0.25, 0.5, 0.75, 0.975))
  })
})
## PLOTS -----
## filename ----
pdf(file = paste("../fig/social/global_degree", 
                 fit.social.sacr.mcmc$date_time, ".pdf", sep = ""),
    height = 7, width = 10)
## global plot commands ----
layout(1); par(mar = c(2.6, 4.1, 2.6, 0.6))
time.window <- range(ot.sacr.real)
time.window.numeric <- as.numeric(time.window)
it.sacr.real <- sapply(1:n.indiv, function(i){
  as.POSIXct(interp.times[[i]]*diff(time.window.numeric) + time.window.numeric[1],
             origin = "1970-01-01")
}, simplify = F)
##
plot(it.sacr.real[[1]], mean_degree.quantiles[3, ], type = "n", 
     ylim = range(c(0, max_degree.quantiles)), 
     main = "network degree", xlab = "", ylab = "degree", axes = T)
##
# axis(1, at = as.POSIXct(seq(min(it.sacr.real[[1]]), max(it.sacr.real[[1]]), l=5), 
#                         origin = "1970-01-01"),
#      labels = as.Date(as.POSIXct(seq(min(it.sacr.real[[1]]), max(it.sacr.real[[1]]), l=5), 
#                                  origin = "1970-01-01"), format = "%b-%d"))
polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])), 
        y = c(mean_degree.quantiles[1, ], rev(mean_degree.quantiles[5, ])),
        col = scales::alpha("gray", 0.3), border = "NA")
polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])), 
        y = c(mean_degree.quantiles[2, ], rev(mean_degree.quantiles[4, ])),
        col = scales::alpha("gray", 0.75), border = "NA")
lines(it.sacr.real[[1]], mean_degree.quantiles[3, ], lwd = 2, lty = 1)
##
polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])), 
        y = c(max_degree.quantiles[1, ], rev(max_degree.quantiles[5, ])),
        col = scales::alpha("gray", 0.3), border = "NA")
polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])), 
        y = c(max_degree.quantiles[2, ], rev(max_degree.quantiles[4, ])),
        col = scales::alpha("gray", 0.75), border = "NA")
lines(it.sacr.real[[1]], max_degree.quantiles[3, ], lwd = 2, lty = 2)
##
polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])), 
        y = c(min_degree.quantiles[1, ], rev(min_degree.quantiles[5, ])),
        col = scales::alpha("gray", 0.3), border = "NA")
polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])), 
        y = c(min_degree.quantiles[2, ], rev(min_degree.quantiles[4, ])),
        col = scales::alpha("gray", 0.75), border = "NA")
lines(it.sacr.real[[1]], min_degree.quantiles[3, ], lwd = 2, lty = 3)
legend("topright", lwd = 2, lty = c(2, 1, 3), legend = c("max", "mean", "min"),
       bty = "n")
##
# way.pts <- seq(1, length(it.sacr.real[[1]]), l=6)
# points(it.sacr.real[[1]][way.pts],
#        rep(par()$usr[3] - 0.04 * diff(par()$usr[4:3]), length(way.pts)),
#        col = "gray", lwd = 2,
#        pch = 1:length(way.pts), cex = 2, xpd = T)
## dev.off ----
dev.off()
## filename ----
# pdf(file = paste("../fig/social/individual_degrees", fit.social.sacr.mcmc$date_time, ".pdf", sep = ""),
#     width = 10, height = 7)
png(file = paste("../fig/social/individual_degrees", fit.social.sacr.mcmc$date_time, ".png", sep = ""),
    width = 10/2, height = 7/2, units = "in", res = 72*3)
## individual plot commands ----
axis_ticks <- as.POSIXct(paste("2013-", c("09-01", "09-16", "10-01", "10-12", "10-22"), sep = ""), 
                         origin = "1970-01-01", tz = "UTC")
axis_labels <- c("Sep 01", "Sep 16", "Oct 01", "Oct 12", "Oct 22")
layout(1); par(mar = c(2.6, 4.6, 0.6, 0.6))
if(!exists("plot.colors")){
  plot.colors <- RColorBrewer::brewer.pal(9, "Set1")
}
if(!exists("way.pts")){
  way.pts <- seq(1, length(interp.times[[1]]), l=6)
}
plot(it.sacr.real[[1]], ind_degree.quantiles[3, 1, ], 
     ylim = range(c(0, ind_degree.quantiles)), type = "n", 
     xlab = "", xaxt = "n",
     # ylab = expression(paste("individual degree ", d[j](t), "=", sum(w[jk](t), k == 1, J))), 
     ylab = expression(paste("individual degree ", d[j](t))), 
     main = "")
axis(1, at = axis_ticks, labels = axis_labels, cex.axis = 1)
for(i in 1:n.indiv){
  # polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])),
  #         y = c(ind_degree.quantiles[1, i,  ], rev(ind_degree.quantiles[5, i, ])),
  #         col = scales::alpha(plot.colors[i], 0.3), border = "NA")
  polygon(x = c(it.sacr.real[[1]], rev(it.sacr.real[[1]])),
          y = c(ind_degree.quantiles[2, i, ], rev(ind_degree.quantiles[4, i, ])),
          col = scales::alpha(plot.colors[i], 0.4), border = "NA")
  lines(it.sacr.real[[1]], ind_degree.quantiles[3, i, ], lwd = 2, lty = 1,
        col = plot.colors[i])
}
# points(it.sacr.real[[1]][way.pts],
#        rep(par()$usr[3] - 0.04 * diff(par()$usr[4:3]), length(way.pts)),
#        col = "gray", lwd = 2,
#        pch = 1:length(way.pts), cex = 2, xpd = T)
# legend("topright", col = plot.colors[1:n.indiv], lwd = 2, lty = 1,
#        legend = as.character(1:5), bty = "n", title = "individual")
## dev.off ----
dev.off()
## ----