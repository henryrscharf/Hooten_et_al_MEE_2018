###############################################################################
###############################################################################
## Henry Scharf
##
## This script makes diagnostic plots for the output of a call to 
## smover.social.fit() for sandhill crane telemetry data.
###############################################################################
###############################################################################
## libraries ----
library(smover); library(rworldmap)
# ## optionally load another dataset ----
# date <- "YYYYMMDD_HHMMSS"
# load(paste("fit_sacr_indep", date, ".RData", sep = ""))
# list2env(output, envir = environment())
## compute needed variables ----
N.iterations <- length(fit.social.sacr.mcmc$chains$phi.s) - 1
used.iterations <- (floor(N.iterations * 0.5) + 2):(N.iterations + 1)
burnin <- (1:(N.iterations + 1))[-used.iterations]
n.indiv <- length(fit.social.sacr.mcmc$smover_mcmc.object$data$s)
ot.sacr <- fit.social.sacr.mcmc$smover_mcmc.object$data$observation.times
map <- getMap()[c(28,103,135,167),]
map.proj <- spTransform(map, sacr.crs)
## PLOT DIAGNOSTICS ----
## filename ----
pdf(file = paste("diagnostics_sacr_indep", fit.social.sacr.mcmc$date, ".pdf", sep = ""))
## plots ----
plot(fit.social.sacr.mcmc, which.plots = c(1), ask = F, burnin = burnin)
plot(fit.social.sacr.mcmc, which.plots = c(2), ask = F, burnin = burnin)
plot(fit.social.sacr.mcmc, which.plots = c(4), ask = F, burnin = burnin,
     interp.times = interp.times, mu.i = 1:n.indiv, mu.map = F, zoom = c(6, 6, 6))
## dev.off ----
dev.off()
## filename ----
pdf(file = paste("paths_sacr_indep", fit.social.sacr.mcmc$date, ".pdf", sep = ""), width = 14)
## plot north/east ----
## load + project map
# map <- getMap()[c(28,103,167),] #Without Russia
map <- getMap()[c(28,103,135,167),] #With Russia
map.proj <- spTransform(map, sacr.crs)
indivs <- 1:n.indiv
plot.colors <- RColorBrewer::brewer.pal(9, "Set1")
path.subset <- used.iterations
if(length(path.subset) > 200){
  path.subset <- sort(sample(used.iterations, size = 200))
}
alpha.lev <- max(1e-3, min(1, 3/length(path.subset)))
## layout
layout(matrix(c(2, 3, 1, 1), 2, 2), height = c(0.95, 1))
par(mar = c(4.1, 0.6, 0.6, 0.6))
plot(map.proj, bg = "dodgerblue4", lwd = 1, col = "gray", xlim = c(-100, 900), ylim = c(-2200, 3600))
for(iter in path.subset){
  for(i in indivs){
    lines(fit.social.sacr.mcmc$chains$mu[[iter]][[i]],
          col = scales::alpha(plot.colors[i], alpha.lev))
    way.pts <- seq(1, length(interp.times[[i]]), l=6)
    points(fit.social.sacr.mcmc$chains$mu[[iter]][[i]][way.pts, ],
           col = scales::alpha(plot.colors[i], alpha.lev), 
           pch = 1:length(way.pts), cex = 2)
  }
}
for(i in indivs){
  points(fit.social.sacr.mcmc$smover_mcmc.object$data$s[[i]],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
## northing
par(mar = c(1.6, 4.1, 0.6, 0.1))
plot(interp.times[[indivs[1]]],
     fit.social.sacr.mcmc$chains$mu[[N.iterations]][[indivs[1]]][, 1],
     type = "n", xlab = "", xaxt = "n", ylab = "northing",
     ylim = range(unlist(lapply(fit.social.sacr.mcmc$chains$mu[path.subset],
                                function(mu.iter){
                                  lapply(mu.iter, function(mu.iter.i){
                                    range(mu.iter.i[, 1])
                                  })
                                }))))
for(iter in path.subset){
  for(i in indivs){
    lines(interp.times[[i]],
          fit.social.sacr.mcmc$chains$mu[[iter]][[i]][, 1],
          col = scales::alpha(plot.colors[i], alpha.lev))
    # way.pts <- seq(1, length(interp.times[[i]]), l=6)
    # points(interp.times[[i]][way.pts],
    #        fit.social.sacr.mcmc$chains$mu[[iter]][[i]][way.pts, 1],
    #        col = scales::alpha(plot.colors[i], alpha.lev), 
    #        pch = 1:length(way.pts), cex = 2)
  }
}
for(i in indivs){
  points(fit.social.sacr.mcmc$smover_mcmc.object$data$observation.times[[i]],
         fit.social.sacr.mcmc$smover_mcmc.object$data$s[[i]][, 1],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
way.pts <- seq(1, length(interp.times[[i]]), l=6)
points(interp.times[[i]][way.pts],
       rep(par()$usr[3] - 0.04 * diff(par()$usr[4:3]), length(way.pts)),
       col = "gray", lwd = 2,
       pch = 1:length(way.pts), cex = 2, xpd = T)
legend("left", lwd = 2, col = plot.colors, legend = 1:n.indiv, bty = "n")
## easting
par(mar = c(4.1, 4.1, 0.1, 0.1))
plot(interp.times[[indivs[1]]],
     fit.social.sacr.mcmc$chains$mu[[N.iterations]][[indivs[1]]][, 2],
     type = "n", xlab = "time", ylab = "easting",
     ylim = range(unlist(lapply(fit.social.sacr.mcmc$chains$mu[path.subset],
                                function(mu.iter){
                                  lapply(mu.iter, function(mu.iter.i){
                                    range(mu.iter.i[, 2])
                                  })
                                }))))
for(iter in path.subset){
  for(i in indivs){
    lines(interp.times[[i]],
          fit.social.sacr.mcmc$chains$mu[[iter]][[i]][, 2],
          col = scales::alpha(plot.colors[i], alpha.lev))
  }
}
for(i in indivs){
  points(fit.social.sacr.mcmc$smover_mcmc.object$data$observation.times[[i]],
         fit.social.sacr.mcmc$smover_mcmc.object$data$s[[i]][, 2],
         pch = 16, cex = 0.5, col = plot.colors[i])
}
way.pts <- seq(1, length(interp.times[[i]]), l=6)
points(interp.times[[i]][way.pts],
       rep(par()$usr[3] - 0.04 * diff(par()$usr[4:3]), length(way.pts)),
       col = "gray", lwd = 2,
       pch = 1:length(way.pts), cex = 2, xpd = T)
## dev.off ----
dev.off()
## Effective Sample Size and Gelman diagnostic ----
library(coda); library(smover)
used.iterations.1 <- used.iterations[1:floor(length(used.iterations)/2)]
used.iterations.2 <- used.iterations[seq(floor(length(used.iterations)/2) + 1, 
                                         length.out = length(used.iterations.1))]
gelman.stat <- lapply(fit.social.sacr.mcmc$chains[1:6], function(param){
  gelman.diag(list(as.mcmc(param[used.iterations.1]),
                   as.mcmc(param[used.iterations.2])), autoburnin = F)
})
gelman.stat
ess <- lapply(fit.social.sacr.mcmc$chains[c(1, 3, 4, 5)], function(param){
  effectiveSize(as.mcmc(param[used.iterations]))
})
ess
## compute path uncertainty ----
get.path.dist <- function(mu = NULL, mu.mean = NULL){
  mu.array <- array(unlist(mu), dim = c(dim(mu[[1]]), length(mu)))
  mu.radii <- sapply(1:dim(mu.array)[3], function(i){
    sapply(1:dim(mu.array)[1], function(t){
      dist(rbind(mu.array[t, , i], mu.mean[t, , i]))
    })
  })
  return(mu.radii)
}
system.time({
  mu.array <- array(unlist(fit.social.sacr.mcmc$chains$mu[used.iterations]),
                    dim = c(dim(fit.social.sacr.mcmc$chains$mu[[1]][[1]]), 
                            length(fit.social.sacr.mcmc$chains$mu[[1]]), 
                            length(used.iterations)))
  mu.mean <- apply(mu.array, 1:3, mean)
  cl <- parallel::makeForkCluster(6)
  mu.radii <- array(parallel::parSapply(cl, used.iterations, FUN = function(iter){
    get.path.dist(mu = fit.social.sacr.mcmc$chains$mu[[iter]], mu.mean = mu.mean)
  }), dim = c(dim(mu.mean)[c(1, 3)], length(used.iterations)))
  parallel::stopCluster(cl)
  mu.quantiles <- apply(mu.radii, 1:2, function(mu.i.t){
    quantile(mu.i.t, prob = 0.95)
  })
})

## SAVE PATH UNCERTAINTY QUANTILES ----
save(mu.quantiles, used.iterations, N.iterations, 
     file = paste("path_uncertainty_indep", fit.social.sacr.mcmc$date_time, ".RData", sep = ""))
