sie.bma.mcmc <- function(out.list,bf.vec){

#
#  Performs Barker and Link RJMCMC using individ. model fit output
#  to get posterior model probabilities.
#

####
####  Create Variables
####

n.mcmc=out.list[[1]]$n.mcmc
n.warps=length(out.list)

n=dim(out.list[[1]]$S)[1]
m=length(out.list[[1]]$mu.times)

phi.vals=out.list[[1]]$phi.vals
mu.times=out.list[[1]]$mu.times
mu.0=out.list[[1]]$mu.0
map.idx=out.list[[1]]$map.idx

####
####  Storage Variables 
####

phi.save=rep(0,n.mcmc)
phi.idx.save=rep(0,n.mcmc)
s2.s.save=rep(0,n.mcmc)
s2.mu.save=rep(0,n.mcmc)
model.idx.save=rep(1,n.mcmc)
mu.times.save=matrix(0,m,n.mcmc)
bf.save=rep(0,n.mcmc)

model.idx=1

####
####  Begin MCMC Loop
####

for(k in 1:n.mcmc){
  if((k%%100)==0){cat(k," ")} 

  ####
  ####  Calculate Full-Cond. Model Probability  
  ####

  lp=rep(0,n.warps)
  p=rep(0,n.warps)
  for(j in 1:n.warps){
    lp[j]=out.list[[j]]$ld.save[k]
  }
  for(j in 1:n.warps){
    p[j]=1/(1+sum(exp(lp[-j]-lp[j])))
  }

  model.idx=sample(1:n.warps,1,prob=p) 

  ####
  ####  Save Variables
  ####

  bf.save[k]=bf.vec[model.idx]
  model.idx.save[k]=model.idx 
  mu.times.save[,k]=out.list[[model.idx]]$mu.times
  phi.save[k]=out.list[[model.idx]]$phi.save[k]
  phi.idx.save[k]=out.list[[model.idx]]$phi.idx.save[k]
  s2.s.save[k]=out.list[[model.idx]]$s2.s.save[k]
  s2.mu.save[k]=out.list[[model.idx]]$s2.mu.save[k]

}
cat("\n")

####
####  Calculate Final Quantities 
####

n.burn=round(.2*n.mcmc)

bma.probs=cbind(seq(1,n.warps,1),table(cut(model.idx.save[-(1:n.burn)],seq(0,n.warps,1)))/(n.mcmc-n.burn))

####
####  Write Output
####

n.warps=n.warps-1

list(model.idx.save=model.idx.save,n.mcmc=n.mcmc,phi.save=phi.save,phi.idx.save=phi.idx.save,s2.s.save=s2.s.save,s2.mu.save=s2.mu.save,n.warps=n.warps,n=n,m=m,phi.vals=phi.vals,mu.times=mu.times,mu.0=mu.0,map.idx=map.idx,n.warps=n.warps,bma.probs=bma.probs,n.burn=n.burn,mu.times.save=mu.times.save,bf.save=bf.save)

}
