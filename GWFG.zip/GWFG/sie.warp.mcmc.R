sie.warp.mcmc <- function(S,s.times,mu.times,map.idx,n.mcmc,n.phi=5,phi.min=.001,phi.max=.005,phi.tune=1,s2.mu.tune=.1,fix.s2.s=NULL,bf="G"){

#
#  Fits FMM with integrated likelihood (s2.mu = s2.mu.old/s2.s when sampling)
# 

#### 
####   Subroutines
#### 

library(msm)

G.tilda.fcn <- function(y,mu,s){
  h.t.vec=1-pnorm(y,mu,s)
  h.t.vec
}

TG.tilda.fcn <- function(y,mu,s,l,u){
  h.t.vec=1-ptnorm(y,mu,s,l,u)
  h.t.vec
}

IBM.tilda.fcn <- function(y,mu,l,u){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<=mu]=(mu-l-y[y<=mu])/(u-l)
  h.t.vec
}

TU.tilda.fcn <- function(y,mu,s,l){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<(mu-s)]=1
  tmp.idx=(y>=(mu-s) & y<mu)
  h.t.vec[tmp.idx]=-2*(y[tmp.idx]-mu)/s-((y[tmp.idx]-mu)^2)/(s^2)
  h.t.vec
}

TD.tilda.fcn <- function(y,mu,s,l){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<mu]=1
  tmp.idx=(y>=mu & y<=(mu+s))
  h.t.vec[tmp.idx]=1-2*(y[tmp.idx]-mu)/s + ((y[tmp.idx]-mu)^2)/(s^2)
  h.t.vec
}

ldmvnorm <- function(y,mu,Sig.inv,ldet){
  d=y-mu
  n=length(y)
  as.numeric(-ldet/2-t(d)%*%Sig.inv%*%d/2)
}

ldig <- function(s2,q,r){
  q*log(r)-lgamma(q)-(q+1)-(r/s2)
}

invgammastrt <- function(igmn,igvar){
  q <- 2+(igmn^2)/igvar
  r <- igmn*((igmn^2)/igvar+1)
  list(r=r,q=q)
}

#### 
####   Setup Variables 
#### 

n=dim(S)[1]
s=as.vector(S)
m=length(mu.times)

phi.save=rep(0,n.mcmc)
phi.idx.save=rep(0,n.mcmc)
s2.s.save=rep(0,n.mcmc)
s2.mu.save=rep(0,n.mcmc)
D.save=rep(0,n.mcmc)

ld.save=rep(0,n.mcmc)

#### 
####   Priors and Starting Values 
#### 

mu.0=S[1,]

s2.s.mn=1.0558e-10
s2.s.var=.00000000001

r=invgammastrt(s2.s.mn,s2.s.var)$r
q=invgammastrt(s2.s.mn,s2.s.var)$q

if(!is.null(fix.s2.s)){
  s2.s=fix.s2.s
}
if(is.null(fix.s2.s)){
  s2.s=.001
}
s2.mu=.01/.001

I.mat=diag(n)

u=20

#### 
####   Prior for phi 
#### 

phi.vals=seq(phi.min,phi.max,,n.phi)
HHprime.sm.array=array(0,c(n,n,n.phi))
for(i in 1:n.phi){
  if((i%%10)==0){cat(i," ")}
  H.t=matrix(0,m,m)
  for(j in 1:m){
    if(bf=="G"){H.t[j,]=G.tilda.fcn(mu.times,mu.times[j],phi.vals[i])}
    if(bf=="TG"){H.t[j,]=TG.tilda.fcn(mu.times,mu.times[j],phi.vals[i],0,1)}
    if(bf=="BM"){H.t[j,]=G.tilda.fcn(mu.times,mu.times[j],mean(phi.vals)/1000)}
    if(bf=="IBM"){H.t[j,]=IBM.tilda.fcn(mu.times,mu.times[j],mu.times[1],mu.times[m])}
    if(bf=="TU"){H.t[j,]=TU.tilda.fcn(mu.times,mu.times[j],4*phi.vals[i],mu.times[1])}
    if(bf=="TD"){H.t[j,]=TD.tilda.fcn(mu.times,mu.times[j],4*phi.vals[i],mu.times[m])}
  }
  HHprime.sm.array[,,i]=(H.t%*%t(H.t))[map.idx,map.idx]
}
cat("\n")
phi.idx=round(n.phi/2)
phi=phi.vals[phi.idx]
HHprime=HHprime.sm.array[,,phi.idx]

Sig=s2.s*(I.mat+s2.mu*HHprime)
Sig.inv=solve(Sig)
ldet=determinant(Sig,logarithm=TRUE)$modulus

s2.mu.acc=0
phi.acc=0

#### 
####   Begin MCMC Loop 
#### 

for(k in 1:n.mcmc){
  if((k%%100)==0){cat(k," (",round(phi.acc/k,2),") ")}

  #### 
  ####   Sample s2.s  
  #### 

  if(is.null(fix.s2.s)){
    q.tmp=q+n
    tmp.1.vec=S[,1]-mu.0[1]
    tmp.2.vec=S[,2]-mu.0[2]
    R.sm.inv=solve(I.mat+s2.mu*HHprime)
    r.tmp=(t(tmp.1.vec)%*%R.sm.inv%*%(tmp.1.vec)+t(tmp.2.vec)%*%R.sm.inv%*%(tmp.2.vec))/2+r
    s2.s=1/rgamma(1,q.tmp,r.tmp) 
  }
  Sig=s2.s*(I.mat+s2.mu*HHprime)
  Sig.inv=solve(Sig)
  ldet=determinant(Sig,logarithm=TRUE)$modulus
  mh.2=ldmvnorm(S[,1],mu.0[1],Sig.inv,ldet)+ldmvnorm(S[,2],mu.0[2],Sig.inv,ldet)

  #### 
  ####   Sample s2.mu  
  #### 

  s2.mu.star=rnorm(1,sqrt(s2.mu),s2.mu.tune)^2 
  if((s2.mu.star > 0) & (sqrt(s2.mu.star) < u)){
    Sig.star=s2.s*(I.mat+s2.mu.star*HHprime)
    Sig.star.inv=solve(Sig.star)
    ldet.star=determinant(Sig.star,logarithm=TRUE)$modulus
    mh.1=ldmvnorm(S[,1],mu.0[1],Sig.star.inv,ldet.star)+ldmvnorm(S[,2],mu.0[2],Sig.star.inv,ldet.star)
    mh=exp(mh.1-mh.2)
    if(mh>runif(1)){
      s2.mu=s2.mu.star
      Sig.inv=Sig.star.inv
      ldet=ldet.star
      mh.2=mh.1
    } 
  }

  #### 
  ####   Sample phi 
  #### 

  phi.idx.star=sample(seq(phi.idx-phi.tune,phi.idx+phi.tune,1),1)
  if((phi.idx.star!=phi.idx) & (phi.idx.star >= 1) & (phi.idx.star <= n.phi)){
    phi.star=phi.vals[phi.idx.star]
    HHprime.star=HHprime.sm.array[,,phi.idx.star]
    Sig.star=s2.s*(I.mat+s2.mu*HHprime.star)
    Sig.star.inv=solve(Sig.star)
    ldet.star=determinant(Sig.star,logarithm=TRUE)$modulus
    mh.1=ldmvnorm(S[,1],mu.0[1],Sig.star.inv,ldet.star)+ldmvnorm(S[,2],mu.0[2],Sig.star.inv,ldet.star)
    mh=exp(mh.1-mh.2)
    if(mh > runif(1)){
      phi.idx=phi.idx.star
      phi=phi.star
      Sig.inv=Sig.star.inv
      HHprime=HHprime.star
      ldet=ldet.star
      phi.acc=phi.acc+1
      mh.2=mh.1
    }
  }

  #### 
  ####   Calculate D for DIC 
  #### 

  D.save[k]=-2*mh.2

  #### 
  ####   Save Samples  
  #### 

  phi.save[k]=phi
  phi.idx.save[k]=phi.idx
  s2.s.save[k]=s2.s
  s2.mu.save[k]=s2.s*s2.mu  # writing out original s2.mu

  #### 
  ####   Save LD Samples for BMA 
  #### 

  ld.s=mh.2  
  ld.prior=ldig(s2.s,q,r)+log(1/u)+log(1/n.phi)
  ld.save[k]=ld.s+ld.prior

}
cat("\n")

#### 
####  Calculate DIC 
#### 

n.burn=round(.1*n.mcmc)
s2.s.mean=mean(s2.s.save[n.burn:n.mcmc])
s2.mu.mean=mean(s2.mu.save[n.burn:n.mcmc])
phi.mean=mean(phi.save[n.burn:n.mcmc])
phi.mean.idx=(1:n.phi)[abs(phi.vals-phi.mean)==min(abs(phi.vals-phi.mean))]

HHprime.mean=HHprime.sm.array[,,phi.mean.idx]
Sig.mean=s2.s*I.mat+s2.mu*HHprime.mean
Sig.mean.inv=solve(Sig.mean)
ldet.mean=determinant(Sig.mean,logarithm=TRUE)$modulus

D.bar=mean(D.save[n.burn:n.mcmc])
D.hat=-2*(ldmvnorm(S[,1],mu.0[1],Sig.mean.inv,ldet.mean)+ldmvnorm(S[,2],mu.0[2],Sig.mean.inv,ldet.mean))
pD=D.bar-D.hat
DIC=D.hat+2*pD

#### 
####  Write Output 
#### 

list(S=S,n.mcmc=n.mcmc,phi.save=phi.save,phi.idx.save=phi.idx.save,s2.s.save=s2.s.save,s2.mu.save=s2.mu.save,mu.times=mu.times,phi.acc=phi.acc,s2.mu.acc=s2.mu.acc,ld.s=ld.s,ld.prior=ld.prior,ld.save=ld.save,phi.vals=phi.vals,mu.0=mu.0,map.idx=map.idx,r=r,q=q,u=u,n=n,m=m,pD=pD,DIC=DIC,D.hat=D.hat,D.bar=D.bar,s2.s.mean=s2.s.mean,s2.mu.mean=s2.mu.mean,phi.mean=phi.mean)

}
