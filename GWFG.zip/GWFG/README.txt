The files included in this directory are intended to fit the basis function movement model (Hooten and Johnson, 2017) to a set of Greenland White-Fronted Goose telemetry data as they migrate from Ireland to a stopover in Iceland (data provided by M. Weegman).  The telemetry data have been scaled to fit the models (GWFG.RData), and because of their use in other ongoing research that has not yet been published.  

To fit the models and obtain graphical output use the following command in an R working directory: 

source("GWFG_script.R")

The script file reads in the remaining R functions as needed:  

sie.warp.mcmc.R:  Contains the main MCMC algorithm to fit the basis function movement model. 
score.warps.R:  Scores a set of models with different warping functions based on fixed parameter values.
sie.bma.mcmc.R:  Performs Barker and Link RJMCMC approach to obtain posterior model probabilities. 
pred.bma.R:  Interpolates movement trajectories based on model averaging output.

