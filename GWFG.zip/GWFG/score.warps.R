score.warps <- function(S,s.times,map.idx,tau.mat,s2.s,s2.mu,phi,bf="G"){

#
#  Score warps before fitting final model, based on preliminary basis function and parameter estimates
#

####
####  Libraries and Subroutines
####

G.tilda.fcn <- function(y,mu,s){
  h.t.vec=1-pnorm(y,mu,s)
  h.t.vec
}

library(msm)
TG.tilda.fcn <- function(y,mu,s,l,u){
  h.t.vec=1-ptnorm(y,mu,s,l,u)
  h.t.vec
}

IBM.tilda.fcn <- function(y,mu,l,u){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<=mu]=(mu-l-y[y<=mu])/(u-l)
  h.t.vec
}

TU.tilda.fcn <- function(y,mu,s,l){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<(mu-s)]=1
  tmp.idx=(y>=(mu-s) & y<mu)
  h.t.vec[tmp.idx]=-2*(y[tmp.idx]-mu)/s-((y[tmp.idx]-mu)^2)/(s^2)
  h.t.vec
}

TD.tilda.fcn <- function(y,mu,s,l){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<mu]=1
  tmp.idx=(y>=mu & y<=(mu+s))
  h.t.vec[tmp.idx]=1-2*(y[tmp.idx]-mu)/s + ((y[tmp.idx]-mu)^2)/(s^2)
  h.t.vec
}

ldmvnorm <- function(y,mu,Sig.inv,ldet){
  d=y-mu
  n=length(y)
  as.numeric(-ldet/2-t(d)%*%Sig.inv%*%d/2)
}

####
####  Loop over warps 
####

mu.0=S[1,]
m=dim(tau.mat)[1]
n.warps=dim(tau.mat)[2]
D.vec=rep(0,n.warps)
I.mat=diag(n)

for(i in 1:n.warps){
  if(i%%100==0){cat(i," ")}
  mu.times=tau.mat[,i]
  H.t=matrix(0,m,m)
  for(j in 1:m){
    
    if(bf=="G"){H.t[j,]=G.tilda.fcn(mu.times,mu.times[j],phi)}
    if(bf=="TG"){H.t[j,]=TG.tilda.fcn(mu.times,mu.times[j],phi,0,1)}
    if(bf=="BM"){H.t[j,]=G.tilda.fcn(mu.times,mu.times[j],mean(phi)/1000)}
    if(bf=="IBM"){H.t[j,]=IBM.tilda.fcn(mu.times,mu.times[j],mu.times[1],mu.times[m])}
    if(bf=="TU"){H.t[j,]=TU.tilda.fcn(mu.times,mu.times[j],4*phi,mu.times[1])}
    if(bf=="TD"){H.t[j,]=TD.tilda.fcn(mu.times,mu.times[j],4*phi,mu.times[m])}

  }
  HHprime=(H.t%*%t(H.t))[map.idx,map.idx]

  Sig=s2.s*I.mat+s2.mu*HHprime
  Sig.inv=solve(Sig)
  ldet=determinant(Sig,logarithm=TRUE)$modulus
  D.vec[i]=-2*(ldmvnorm(S[,1],mu.0[1],Sig.inv,ldet)+ldmvnorm(S[,2],mu.0[2],Sig.inv,ldet))
}
cat("\n")

p.vec=exp(-(D.vec-min(D.vec))/2)/sum(exp(-(D.vec-min(D.vec))/2))

####
####  Write Output 
####

list(D.vec=D.vec,tau.mat=tau.mat,p.vec=p.vec)


}
