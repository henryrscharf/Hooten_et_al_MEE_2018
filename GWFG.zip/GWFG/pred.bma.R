pred.bma <- function(S,tau.mat,out.bma,orig.times){

#
#  Obtains predictions (interpolations) using BMA results
#  Reduces computation time because it only obtains predictions from models 
#  as necessary (instead of from all models). 
#

####
####  Libraries and Subroutines 
####

library(msm)

G.tilda.fcn <- function(y,mu,s){
  h.t.vec=1-pnorm(y,mu,s)
  h.t.vec
}

TG.tilda.fcn <- function(y,mu,s,l,u){
  h.t.vec=1-ptnorm(y,mu,s,l,u)
  h.t.vec
}

IBM.tilda.fcn <- function(y,mu,l,u){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<=mu]=(mu-l-y[y<=mu])/(u-l)
  h.t.vec
}

TU.tilda.fcn <- function(y,mu,s,l){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<(mu-s)]=1
  tmp.idx=(y>=(mu-s) & y<mu)
  h.t.vec[tmp.idx]=-2*(y[tmp.idx]-mu)/s-((y[tmp.idx]-mu)^2)/(s^2)
  h.t.vec
}

TD.tilda.fcn <- function(y,mu,s,l){
  h.t.vec=rep(0,length(y))
  h.t.vec[y<mu]=1
  tmp.idx=(y>=mu & y<=(mu+s))
  h.t.vec[tmp.idx]=1-2*(y[tmp.idx]-mu)/s + ((y[tmp.idx]-mu)^2)/(s^2)
  h.t.vec
}

####
####  Create Variables
####

n.mcmc=out.bma$n.mcmc
n.warps=out.bma$n.warps

m=out.bma$m
n=out.bma$n

Resid.save=array(0,c(n,2,n.mcmc))
bf.save=out.bma$bf.save
phi.vals=out.bma$phi.vals
phi.idx.save=out.bma$phi.idx.save
phi.save=out.bma$phi.save
model.idx.save=out.bma$model.idx.save
s2.mu.save=out.bma$s2.mu.save
s2.s.save=out.bma$s2.s.save
n.phi=length(phi.vals)
mu.times.save=out.bma$mu.times.save
mu.0=out.bma$mu.0
map.idx=out.bma$map.idx

Kprimes.1=rep(0,m)
Kprimes.1[map.idx]=S[,1]-mu.0[1]
Kprimes.2=rep(0,m)
Kprimes.2[map.idx]=S[,2]-mu.0[2]

KprimeK=matrix(0,m,m)
diag(KprimeK)[map.idx]=1

####
####  Storage Variables 
####

MU.save=array(0,c(m,2,n.mcmc))

deriv=rep(0,m-1)

####
####  Begin MCMC Loop
####

for(k in 1:n.mcmc){
  if((k%%100)==0){cat(k," ")} 

  ####
  ####  Compute H 
  ####

  H.t=matrix(0,m,m)
  for(j in 1:m){
    if(bf.save[k]=="G"){H.t[j,]=G.tilda.fcn(mu.times.save[,k],mu.times.save[j,k],phi.save[k])}
    if(bf.save[k]=="TG"){H.t[j,]=TG.tilda.fcn(mu.times.save[,k],mu.times.save[j,k],phi.save[k],0,1)}
    if(bf.save[k]=="BM"){H.t[j,]=G.tilda.fcn(mu.times.save[,k],mu.times.save[j,k],mean(phi.vals)/1000)}
    if(bf.save[k]=="IBM"){H.t[j,]=IBM.tilda.fcn(mu.times.save[,k],mu.times.save[j,k],mu.times.save[1,k],mu.times.save[m,k])}
    if(bf.save[k]=="TU"){H.t[j,]=TU.tilda.fcn(mu.times.save[,k],mu.times.save[j,k],4*phi.save[k],mu.times.save[1,k])}
    if(bf.save[k]=="TD"){H.t[j,]=TD.tilda.fcn(mu.times.save[,k],mu.times.save[j,k],4*phi.save[k],mu.times.save[m,k])}
    if(H.t[j,m]!=0){H.t[j,m]=0}
  }

  HHprime.inv=solve(H.t%*%t(H.t)+0.000001*diag(m))

  ####
  ####  Compute Precision 
  ####
 
  Sig.mu.inv=HHprime.inv/s2.mu.save[k]
 
  ####
  ####  Save Predictions for MU 
  ####

  A=KprimeK/s2.s.save[k]+Sig.mu.inv
  b.1=Kprimes.1/s2.s.save[k]
  tmp.chol=chol(A)
  MU.save[,1,k]=mu.0[1]+backsolve(tmp.chol,backsolve(tmp.chol,b.1,transpose=TRUE)+rnorm(m)) 

  b.2=Kprimes.2/s2.s.save[k]
  MU.save[,2,k]=mu.0[2]+backsolve(tmp.chol,backsolve(tmp.chol,b.2,transpose=TRUE)+rnorm(m)) 

  ####
  ####  Compute Posterior Mean Derivative of MU 
  ####

  deriv=deriv+diff(mu.times.save[,k]-orig.times)/n.mcmc

  ####
  ####  Save Residuals
  ####

  Resid.save[,1,k]=S[,1]-MU.save[map.idx,1,k]
  Resid.save[,2,k]=S[,2]-MU.save[map.idx,2,k]

}
cat("\n")

####
####  Make TG BF based on posterior mean param and warp 
####

H.t.mean=matrix(0,m,m)
for(j in 1:m){
  H.t.mean[j,]=TG.tilda.fcn(mu.times.save[,k],mu.times[j],phi.save[k],0,1)
}

####
####  Write Output
####

list(MU.save=MU.save,n.mcmc=n.mcmc,deriv=deriv,n.mcmc=n.mcmc,H.t.mean=H.t.mean,Resid.save=Resid.save,mu.times=mu.times,S=S,out.bma=out.bma)

}
