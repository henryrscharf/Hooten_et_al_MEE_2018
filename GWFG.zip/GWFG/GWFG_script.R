####
####  Code to fit FMM (Hooten and Johnson, 2017, JASA; Hooten et al., 2018, MEE) to GWFG data
####
####  Loops over each individual and compiles results
####

####
####  Read in GWFG data
####

library(maps)
library(chron)
load("GWFG.RData")

####
####  Create Warps
####

cat("\n","getting warps", "\n")
library(msm)

n.sig=10
n.phi=10
sig.vec=seq(.6,.8,,n.sig)
phi.vec=seq(.1,.25,,n.phi)^2
warp.grd=expand.grid(sig.vec,phi.vec)
n.grd=dim(warp.grd)[1]

n.warps=100
t.star=seq(.2,.8,,n.warps)
warp.list=vector("list",n.grd)
for(i in 1:n.grd){
  cat(i," ")
  warp.list[[i]]=matrix(0,m,n.warps)
  for(j in 1:n.warps){
    warp.list[[i]][,j]=(warp.grd[i,1]*ptnorm(mu.times,t.star[j],warp.grd[i,2],mu.times[1],mu.times[m])+mu.times-mu.times[1])/(warp.grd[i,1]+mu.times[m]-mu.times[1])
  }
}
cat("\n")
warp.mat=matrix(unlist(warp.list),m)


####
####  Loop to Fit Model for each Individ 
####
####  This procedure reduces computing time by fitting an initial model to prescore warps 
####  then it fits the FMM to a subset of warps that scored well based on initial model fit. 
####  This loop could also be done in parallel.  
####

library(sp)

pop.out.list=vector("list",n.individ)
bma.out.list=vector("list",n.individ)
n.mcmc=10000

for(ii in 1:n.individ){
  cat("individ:", ii, "\n")

  ####
  ####  Step 1
  ####  Prepare Data for FMM
  ####

  s.times=s.times.list[[ii]]
  S=S.list[[ii]]
  n=n.list[[ii]]
  map.idx=map.idx.list[[ii]]

  ####
  ####  Step 2 
  ####  Fit Initial Homogeneous Models 
  ####
  ####  This step can be skipped if you don't do pre-scoring approach.
  ####

  cat("\n","fit homog model", "\n")

  bf.names=c("TG")
  n.bf=length(bf.names)
  init.mcmc.out=vector("list",n.bf)
  source("sie.warp.mcmc.R")
  for(j in 1:n.bf){
    init.mcmc.out[[j]]=sie.warp.mcmc(S,s.times,mu.times,map.idx,10000,100,.001,.02,5,.5,bf=bf.names[j])
  }

  ####
  ####  Step 3 
  ####  Get Pre-Scores using Prelim Model Fit 
  ####
  ####  This step can be skipped if you don't do pre-scoring approach.
  ####

  cat("\n","Get pre-scores", "\n")

  dim(warp.mat)[2]  # number of warps
  score.list=vector("list",n.bf)
  P.mat=matrix(0,dim(warp.mat)[2],n.bf)
  D.mat=matrix(0,dim(warp.mat)[2],n.bf)
  source("score.warps.R")
  for(j in 1:n.bf){
    score.list[[j]]=score.warps(S,s.times,map.idx,warp.mat,init.mcmc.out[[j]]$s2.s.mean,init.mcmc.out[[j]]$s2.mu.mean,init.mcmc.out[[j]]$phi.mean,bf=bf.names[j])
    P.mat[,j]=score.list[[j]]$p.vec
    D.mat[,j]=score.list[[j]]$D.vec
  }
  P.all.mat=exp(-(D.mat-min(D.mat))/2)/sum(exp(-(D.mat-min(D.mat))/2))

  thresh=20
  P.all.vec=as.vector(P.all.mat)
  tmp.1.idx=(1:dim(warp.mat)[2])[order(P.all.vec,decreasing=TRUE)][1:thresh]
  tmp.2.idx=tmp.1.idx

  n.sm.warps=length(tmp.2.idx)
  n.sm.warps

  warp.sm.mat=(matrix(1,1,n.bf)%x%warp.mat)[,tmp.2.idx]
  bf.sm.vec=rep(bf.names,each=dim(warp.mat)[2])[tmp.2.idx]
  P.sm.vec=P.all.vec[tmp.2.idx]

  ####
  ####  Step 4 
  ####  Fit Models to Pre-Scored Warps
  ####
  ####  This step can be performed over all warps if you don't do pre-scoring approach.
  ####

  cat("\n","Fit warped models", "\n")

  out.list=vector("list",n.sm.warps)
  source("sie.warp.mcmc.R")
  for(j in 1:n.sm.warps){
    cat(j,"\n")
    out.list[[j]]=sie.warp.mcmc(S,s.times,warp.sm.mat[,j],map.idx,n.mcmc,10000,.001,.02,5,.5,bf=bf.sm.vec[j])
  }
  cat("\n")

  ####
  ####  Step 5 
  ####  RJMCMC for BMA
  ####

  cat("\n", "Do BMA", "\n")

  source("sie.bma.mcmc.R")
  out.bma=sie.bma.mcmc(out.list,bf.sm.vec)
  table(out.bma$bf.save)/out.bma$n.mcmc

  ####
  ####  Step 6 
  ####  Get Predictions
  ####

  cat("\n", "Get Predictions", "\n")

  source("pred.bma.R")
  pred.out=pred.bma(S,warp.sm.mat,out.bma,mu.times)

  ###
  ###  End Loop over individ 
  ###

  pop.out.list[[ii]]=pred.out  
  bma.out.list[[ii]]=out.bma 

}; cat("\n")
 
save(pop.out.list,bma.out.list,mu.times,s.times,file="GWFG_output.RData")

####
####  Read in GWFG data and model output
####

library(maps)
library(chron)
library(scales)
library(RColorBrewer)
load("GWFG.RData")
load("GWFG_output.RData")

####
####  Plot maps of data and model output
####

n.samp=20
n.burn=pop.out.list[[4]]$out.bma$n.burn
n.mcmc=pop.out.list[[4]]$out.bma$n.mcmc
samp.idx=round(seq(n.burn,n.mcmc,,n.samp))

n.burn=pop.out.list[[1]]$out.bma$n.burn
n.mcmc=pop.out.list[[1]]$out.bma$n.mcmc
mu.times=pop.out.list[[1]]$mu.times
m=length(mu.times)
mu.times.mat=matrix(0,m,n.individ)

MU.1.mat=matrix(0,m,n.individ*n.samp)
MU.2.mat=matrix(0,m,n.individ*n.samp)
deriv.mat=matrix(0,m-1,n.individ)

GWFG.colors.orig=RColorBrewer::brewer.pal(9,"Set1")
GWFG.colors=alpha(GWFG.colors.orig,.15)
GWFG.colors.2=alpha(GWFG.colors.orig,.35)

layout(matrix(1:4,2,2))
par(mar=c(3,4,1,2),cex.axis=1.25)
for(i in 1:n.individ){
  mu.times.mat[,i]=pop.out.list[[i]]$mu.times
  S=S.list[[i]]
  plot(S,type="p",col=GWFG.colors.orig[which(i==(1:n.individ))],asp=TRUE)
  for(j in 1:n.samp){
    MU=pop.out.list[[i]]$MU.save[,,samp.idx[j]]
    names(MU)=c("lon","lat")
    MU.1.mat[,n.samp*(i-1)+j]=MU[,1]
    MU.2.mat[,n.samp*(i-1)+j]=MU[,2]
    lines(MU[,1],MU[,2],col=GWFG.colors[which(i==(1:n.individ))],lwd=2,pch=20)
  }
}

####
####  Plot warp derivatives
####

for(i in 1:n.individ){
  S=S.list[[i]]
  deriv.mat[,i]=pop.out.list[[i]]$deriv
}

delta.t=mu.times[2]-mu.times[1]
plot(mu.times.mat[-1,1],pop.out.list[[1]]$deriv/delta.t,type="n",col=GWFG.colors.orig[1],ylab="",xlab="",lwd=2,yaxt="n",ylim=range(deriv.mat/delta.t))
mtext("dw(t)/dt",2,line=1,cex=1)
polygon(c(mu.times.mat[-1,1],mu.times.mat[2,1]),c(pop.out.list[[1]]$deriv,pop.out.list[[1]]$deriv[1])/delta.t,border=GWFG.colors.orig[1],col=GWFG.colors.2[1],lwd=.5)
for(i in 2:n.individ){
  delta.t=pop.out.list[[i]]$mu.times[2]-pop.out.list[[i]]$mu.times[1]
  polygon(c(mu.times.mat[-1,i],mu.times.mat[2,1]),c(pop.out.list[[i]]$deriv,pop.out.list[[i]]$deriv[1])/delta.t,border=GWFG.colors.orig[i],col=GWFG.colors.2[i],lwd=.5)
}
abline(h=1,col=8,lty=2)

